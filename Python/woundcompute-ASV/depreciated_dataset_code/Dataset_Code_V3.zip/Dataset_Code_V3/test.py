import os
import pathlib

path_input_fn = 'C:/Working Folder/C5/240311_171147_20240311_R5BP4_NHDFneo_P5_F127'
path_output_fn = 'C:/Working Folder/C5/240311_171147_20240311_R5BP4_NHDFneo_P5_F127/Sorted'
name = 'Sorted'
a = str(os.path.join(path_input_fn, name))
b = pathlib.Path(path_output_fn)
c = path_input_fn + '/' + name
print(a==path_output_fn)
print(b==path_output_fn)
print(c==path_output_fn)
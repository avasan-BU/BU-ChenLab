from wc_functions_2_2 import woundcompute_run_Eclipse_Ti as wc_run
import sys

location = sys.argv[1]
print("Starting Thread 1")
_ = wc_run(location)

